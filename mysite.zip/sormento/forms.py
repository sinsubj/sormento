from django import forms
from models import *

#class CategoryForm(forms.ModelForm):
#    name = forms.CharField(max_length=64, help_text="Please enter the source type name.")
#
#    class Meta:
#        model = Category

#class RootForm(forms.ModelForm):
#    class Meta:
#        model = Root
#        exclude = ('user', 'slug',)