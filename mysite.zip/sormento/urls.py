from django.conf.urls import patterns, url
#from views import *

urlpatterns = patterns('',
        )

        #url(r'^$', MementoView.as_view(), name="index"),
        #url(r'add_source_type/$', add_source_type, name='add_source_type'),
        #url(r'mementos/(?P<pk>\d+)/$', MementoDetail.as_view(), name='memento_detail'),
        #url(r'sources/(?P<root>[-\w]+)/(?P<node>[-\w]+)/$', SourceDetail.as_view(), name='node_detail'),
        #url(r'sources/(?P<root>[-\w]+)/$', SourceDetail.as_view(), name='root_detail'),
        #url(r'^goto/$', track_url, name='track_url'),

        #url(r'manage/add_main/$', RootAdd.as_view(), name='main_add'),
        #url(r'add/$', CategoryCreate.as_view(), name='source_type_add'),
        #url(r'update/(?P<pk>\d+)/$', CategoryUpdate.as_view(), name='source_type_update'),
        #url(r'delete/(?P<pk>\d+)/$', CategoryDelete.as_view(), name='source_type_delete'),